package com.epam.rd.autotasks.arithmeticexpressions;

public interface Expression {
    int evaluate();
    String toExpressionString();
}
